"""LOVE HAND - versi web (Streamlit + streamlit-webrtc). Logika sama dengan love_hand.py."""
import math, time
import av, cv2, numpy as np
import mediapipe as mp
import streamlit as st
from streamlit_webrtc import webrtc_streamer, VideoProcessorBase, RTCConfiguration

PARTNER_NAME = "SHEILA"
BIRTHDAY_MESSAGE = "HAPPY BIRTHDAY SAYANG"
LOVE_TEXT = f"I ALWAYS LOVE YOU {PARTNER_NAME}"

CANVAS_W, CANVAS_H = 900, 600
CAM_W, CAM_H, CAM_MARGIN = 260, 195, 18
FONT = cv2.FONT_HERSHEY_DUPLEX
N = 2400
DEBOUNCE = 5
FOLLOW_EASE, RETURN_EASE = 6.0, 3.0
MAX_OX, MAX_OY = CANVAS_W * 0.32, CANVAS_H * 0.30
CENTER = np.array([CANVAS_W / 2, CANVAS_H / 2], dtype=np.float32)


def text_to_points(text):
    th_ = 3
    scale = 3.5
    while scale > 0.3:
        (tw, _), _ = cv2.getTextSize(text, FONT, scale, th_)
        if tw <= CANVAS_W * 0.85:
            break
        scale -= 0.05
    (tw, th), _ = cv2.getTextSize(text, FONT, scale, th_)
    mask = np.zeros((CANVAS_H, CANVAS_W), np.uint8)
    cv2.putText(mask, text, ((CANVAS_W - tw) // 2, (CANVAS_H + th) // 2), FONT, scale, 255, th_, cv2.LINE_AA)
    ys, xs = np.nonzero(mask)
    pts = np.column_stack((xs, ys)).astype(np.float32)
    return pts[np.random.choice(len(pts), N, replace=len(pts) < N)]


def heart_points():
    t = np.random.uniform(0, 2 * np.pi, N)
    r = np.sqrt(np.random.uniform(0, 1, N))
    x = 16 * np.sin(t) ** 3 * r
    y = -(13 * np.cos(t) - 5 * np.cos(2 * t) - 2 * np.cos(3 * t) - np.cos(4 * t)) * r
    s = min(CANVAS_W, CANVAS_H) / 40
    return np.column_stack((x * s + CENTER[0], y * s + CENTER[1] - 40)).astype(np.float32)


def libra_points(scale=1.9):
    pad, b = 200, 70
    mask = np.zeros((pad * 2, pad * 2), np.uint8)
    cx = cy = pad
    cv2.line(mask, (cx - b, cy - 45), (cx + b, cy - 45), 255, 12, cv2.LINE_AA)
    cv2.line(mask, (cx, cy - 45), (cx, cy - 8), 255, 12, cv2.LINE_AA)
    cv2.ellipse(mask, (cx, cy + 8), (b, 45), 0, 0, 180, 255, 12, cv2.LINE_AA)
    cv2.line(mask, (cx - b, cy + 53), (cx + b, cy + 53), 255, 12, cv2.LINE_AA)
    ys, xs = np.nonzero(mask)
    pts = (np.column_stack((xs, ys)).astype(np.float32) - [cx, cy]) * scale + CENTER
    return pts[np.random.choice(len(pts), N, replace=len(pts) < N)].astype(np.float32)


@st.cache_resource
def build_targets():
    return {"heart": heart_points(), "zodiac": libra_points(),
            "love": text_to_points(LOVE_TEXT), "bday": text_to_points(BIRTHDAY_MESSAGE)}


COLORS = {
    "scatter": np.array([235, 225, 215], np.float32), "heart": np.array([150, 110, 255], np.float32),
    "zodiac": np.array([200, 220, 255], np.float32), "love": np.array([235, 210, 70], np.float32),
    "bday": np.array([90, 210, 255], np.float32)}
LABELS = {
    "scatter": "Tangan terbuka / tanpa tangan -- partikel menyebar",
    "heart": "0 jari (kepal) -- HATI", "zodiac": "1 jari -- zodiak LIBRA",
    "love": "2 jari (peace) -- pesan cinta", "bday": "3 jari -- ucapan ulang tahun"}
PALM_IDS = [0, 5, 9, 13, 17]


def dist(a, b):
    return math.hypot(a.x - b.x, a.y - b.y)


def count_fingers(lm):
    c = sum(1 for tip, pip in zip([8, 12, 16, 20], [6, 10, 14, 18]) if lm[tip].y < lm[pip].y - 0.02)
    if dist(lm[4], lm[17]) > dist(lm[3], lm[17]) + 0.02:
        c += 1
    return c


class LoveHand(VideoProcessorBase):
    def __init__(self):
        self.targets = build_targets()
        self.hands = mp.solutions.hands.Hands(max_num_hands=1, model_complexity=0,
                                              min_detection_confidence=0.65, min_tracking_confidence=0.55)
        self.rng = np.random.default_rng()
        self.spos = np.clip(self.rng.normal(CENTER, [CANVAS_W * .22, CANVAS_H * .22], (N, 2)),
                            0, [CANVAS_W, CANVAS_H]).astype(np.float32)
        self.svel = self.rng.uniform(-20, 20, (N, 2)).astype(np.float32)
        self.pos = self.spos.copy()
        self.phase = self.rng.uniform(0, 6.283, N).astype(np.float32)
        self.tspeed = self.rng.uniform(1, 3, N).astype(np.float32)
        self.color = COLORS["scatter"].copy()
        self.tracked = CENTER.copy()
        self.active = self.pending = "scatter"
        self.pcount = 0
        self.activated = False
        self.t0 = self.prev = time.time()

    def recv(self, frame):
        img = cv2.flip(frame.to_ndarray(format="bgr24"), 1)
        img = cv2.resize(img, (640, 480))
        now = time.time()
        dt = max(1e-3, min(0.05, now - self.prev))
        self.prev = now

        res = self.hands.process(cv2.cvtColor(img, cv2.COLOR_BGR2RGB))
        detected, raw, hand = "scatter", None, None
        if res.multi_hand_landmarks:
            lm = res.multi_hand_landmarks[0].landmark
            raw = count_fingers(lm)
            detected = {0: "heart", 1: "zodiac", 2: "love", 3: "bday"}.get(raw, "scatter")
            hand = (np.mean([lm[i].x for i in PALM_IDS]), np.mean([lm[i].y for i in PALM_IDS]))
            mp.solutions.drawing_utils.draw_landmarks(
                img, res.multi_hand_landmarks[0], mp.solutions.hands.HAND_CONNECTIONS)

        if not self.activated and raw == 5:
            self.activated, self.pending, self.pcount = True, "scatter", DEBOUNCE
        if detected == self.pending:
            self.pcount += 1
        else:
            self.pending, self.pcount = detected, 1
        if self.activated and self.pcount >= DEBOUNCE:
            self.active = self.pending

        # scatter
        self.svel += self.rng.uniform(-8, 8, self.svel.shape).astype(np.float32) * dt
        sp = np.linalg.norm(self.svel, axis=1, keepdims=True) + 1e-6
        self.svel = self.svel / sp * np.minimum(sp, 55.0)
        self.spos += self.svel * dt
        m = 40
        for k, hi in ((0, CANVAS_W - m), (1, CANVAS_H - m)):
            out = (self.spos[:, k] < m) | (self.spos[:, k] > hi)
            self.svel[out, k] *= -1
            self.spos[:, k] = np.clip(self.spos[:, k], m, hi)

        # ikuti tangan
        shape = self.active != "scatter"
        if shape and hand is not None:
            raw_c = np.array([hand[0] * CANVAS_W, hand[1] * CANVAS_H], np.float32)
            ease = 1 - math.exp(-FOLLOW_EASE * dt)
        else:
            raw_c, ease = CENTER, 1 - math.exp(-RETURN_EASE * dt)
        self.tracked += (raw_c - self.tracked) * ease
        off = self.tracked - CENTER
        off[0] = np.clip(off[0], -MAX_OX, MAX_OX)
        off[1] = np.clip(off[1], -MAX_OY, MAX_OY)
        target = self.targets[self.active] + off if shape else self.spos
        self.pos += (target - self.pos) * (1 - math.exp(-(6.5 if shape else 5.0) * dt))
        self.color += (COLORS[self.active] - self.color) * (1 - math.exp(-4.0 * dt))

        # render
        canvas = np.zeros((CANVAS_H, CANVAS_W, 3), np.uint8)
        if self.activated:
            tw = 0.65 + 0.35 * np.sin(self.phase + (now - self.t0) * self.tspeed)
            cols = np.clip(self.color[None] * tw[:, None], 0, 255).astype(np.uint8)
            p = self.pos + self.rng.uniform(-1, 1, self.pos.shape).astype(np.float32)
            xs = np.clip(p[:, 0].astype(np.int32), 0, CANVAS_W - 1)
            ys = np.clip(p[:, 1].astype(np.int32), 0, CANVAS_H - 1)
            canvas[ys, xs] = cols
            canvas = cv2.dilate(canvas, np.ones((3, 3), np.uint8))
        glow = cv2.GaussianBlur(canvas, (0, 0), sigmaX=5)
        canvas = cv2.add(canvas, (glow.astype(np.float32) * 0.6).astype(np.uint8))

        label = LABELS[self.active] if self.activated else "Buka telapak tangan lebar-lebar (5 jari) untuk memulai..."
        cv2.putText(canvas, label, (16, CANVAS_H - 18), cv2.FONT_HERSHEY_SIMPLEX, 0.55, (190, 190, 190), 1, cv2.LINE_AA)
        x0 = y0 = CAM_MARGIN
        canvas[y0:y0 + CAM_H, x0:x0 + CAM_W] = cv2.resize(img, (CAM_W, CAM_H))
        cv2.rectangle(canvas, (x0 - 2, y0 - 2), (x0 + CAM_W + 2, y0 + CAM_H + 2), (90, 90, 90), 2)
        return av.VideoFrame.from_ndarray(canvas, format="bgr24")


st.set_page_config(page_title="LOVE HAND", layout="centered")
st.title("LOVE HAND")
st.caption("Klik START, izinkan kamera, lalu buka telapak tangan lebar-lebar (5 jari).")
webrtc_streamer(
    key="love-hand",
    video_processor_factory=LoveHand,
    rtc_configuration=RTCConfiguration({"iceServers": [{"urls": ["stun:stun.l.google.com:19302"]}]}),
    media_stream_constraints={"video": {"width": 640, "height": 480}, "audio": False},
    async_processing=True,
)
